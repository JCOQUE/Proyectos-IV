/** @odoo-module */

const { Component } = owl

export class KpiCard extends Component {}

KpiCard.template = "owl.KpiCard"