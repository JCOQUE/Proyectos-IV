Tutorial: https://docs.confluent.io/platform/current/platform-quickstart.html
